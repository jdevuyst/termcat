// Compiled by ClojureScript 0.0-2156
goog.provide('cljs.core.match');
goog.require('cljs.core');
cljs.core.match.backtrack = (new Error());
