(ns cljs.core.match)

(def backtrack (js/Error.))
